import os
import time
import threading


def my_function(b):
    time.sleep(1)
    os.mkdir("Yabadaba" + b)


def mnogopotokov():
    start_time = time.time()
    threads = []

    for i in range(1, 101):
        thread = threading.Thread(target=my_function, args=(str(i),))
        threads.append(thread)
        thread.start()

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

    end_time = time.time()
    second = end_time - start_time

    print(f"Время выполнения: {second} секунд")


mnogopotokov()

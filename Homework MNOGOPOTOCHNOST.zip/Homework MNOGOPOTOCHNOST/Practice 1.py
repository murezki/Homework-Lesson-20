import os
import time
def my_function(b):
    time.sleep(1)
    os.mkdir("Yabadaba" + b)

start_time=time.time()

for i in range(1,101):
    my_function(str(i))

end_time= time.time()

second = end_time - start_time

print(f"Время выполнения: {second} секунд")
